import React from 'react'

const NotVerified = () => {
  return (
    
    <>
    <span className='verify_right'>
        Not Verified
    </span>
    </>
  )
}

export default NotVerified