import React from 'react'

const Verified = () => {
  return (
    <>
    <span className='verify_right'>
    <i class="fas fa-check py-1"></i>
    <i class="fas fa-check py-1"></i>
    </span>
    </>
  )
}

export default Verified