import axios from 'axios'
import React, { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { toast } from 'react-toastify'
import apiList from '../../lib/apiList'
import Subfilter from './subfilter'
import data from "../../JsonData/Skill.json"
import { useLocation } from 'react-router-dom'
import SearchFilter from './SearchFilter'
const SkillJobs = () => {
    const location = useLocation();
  
    const [skills, setSkills] = useState(data)

    const handleSort =  (char) => {
        setSkills(data.filter(post => {
            if (char === "") {
              //if query is empty
              return post;
            } else if (post.Skill.charAt(0).toLowerCase().includes(char.toLowerCase())) {
              //returns filtered array
              return post;
            }
          }) ) 
       
    }

    // const fetchSkills = async () => {
    //     await axios.get(apiList.listSkills)
    //         .then((response) => {
    //             setSkills(response.data.skills)
    //         })
    //         .catch((err) => {
    //             console.log(err.response.data);
    //             toast.error(err.response.data.message)
    //         });
    // }

    // useEffect(async () => {
    //     fetchSkills();
    // }, [])

    return (
        <div >
               { location.pathname === '/skilljobs'?
            <div className="jobs_sec_1_skilljob">
                <div className="heading_pic_skilljob">
                    <div className="container">
                        <SearchFilter />

                        <Subfilter />
                    </div>
                </div>
            </div>:null}


            {/* <!-- sec 1 -->

    <!-- sec 2 --> */}

            <div className="jobskill_sec_2">
                <div className="container">

                    {/* 
            <!-- container --> */}

                    <div className="jobskill_sec_2_sub">
                        <h6 className="jobskill_sec_2_heading_1">BROWSE JOBS BY Skill</h6>
                        <hr className="bg-light" />
                        { location.pathname === '/skilljobs'?
                        <div class="company_jobs_section_2_buttons text-left my-4">
                            {/* <button class="company_jobs_section_2_button_sub current d-inline-block mr-1 mb-2 text-uppercase position-relative z-index-1 overflow-hidden align-middle rounded cursor-pointer text-center bg-dark text-height-2 font-weight-normal px-3 py-2 text-white ">Top 100</button> */}
                            <button class="company_jobs_section_2_button_sub d-inline-block mr-1 mb-2 text-uppercase position-relative z-index-1 overflow-hidden align-middle rounded cursor-pointer text-center bg-dark text-height-2 font-weight-normal px-3 py-2 text-white " onClick={() => handleSort('a')}>A</button>
                            <button class="company_jobs_section_2_button_sub d-inline-block mr-1 mb-2 text-uppercase position-relative z-index-1 overflow-hidden align-middle rounded cursor-pointer text-center bg-dark text-height-2 font-weight-normal px-3 py-2 text-white " onClick={() => handleSort('b')}>B</button>
                            <button class="company_jobs_section_2_button_sub d-inline-block mr-1 mb-2 text-uppercase position-relative z-index-1 overflow-hidden align-middle rounded cursor-pointer text-center bg-dark text-height-2 font-weight-normal px-3 py-2 text-white " onClick={() => handleSort('c')}>C</button>
                            <button class="company_jobs_section_2_button_sub d-inline-block mr-1 mb-2 text-uppercase position-relative z-index-1 overflow-hidden align-middle rounded cursor-pointer text-center bg-dark text-height-2 font-weight-normal px-3 py-2 text-white " onClick={() => handleSort('d')}>D</button>
                            <button class="company_jobs_section_2_button_sub d-inline-block mr-1 mb-2 text-uppercase position-relative z-index-1 overflow-hidden align-middle rounded cursor-pointer text-center bg-dark text-height-2 font-weight-normal px-3 py-2 text-white " onClick={() => handleSort('e')}>E</button>
                            <button class="company_jobs_section_2_button_sub d-inline-block mr-1 mb-2 text-uppercase position-relative z-index-1 overflow-hidden align-middle rounded cursor-pointer text-center bg-dark text-height-2 font-weight-normal px-3 py-2 text-white " onClick={() => handleSort('f')}>F</button>
                            <button class="company_jobs_section_2_button_sub d-inline-block mr-1 mb-2 text-uppercase position-relative z-index-1 overflow-hidden align-middle rounded cursor-pointer text-center bg-dark text-height-2 font-weight-normal px-3 py-2 text-white " onClick={() => handleSort('g')}>G</button>
                            <button class="company_jobs_section_2_button_sub d-inline-block mr-1 mb-2 text-uppercase position-relative z-index-1 overflow-hidden align-middle rounded cursor-pointer text-center bg-dark text-height-2 font-weight-normal px-3 py-2 text-white " onClick={() => handleSort('h')}>H</button>
                            <button class="company_jobs_section_2_button_sub d-inline-block mr-1 mb-2 text-uppercase position-relative z-index-1 overflow-hidden align-middle rounded cursor-pointer text-center bg-dark text-height-2 font-weight-normal px-3 py-2 text-white " onClick={() => handleSort('i')}>I</button>
                            <button class="company_jobs_section_2_button_sub d-inline-block mr-1 mb-2 text-uppercase position-relative z-index-1 overflow-hidden align-middle rounded cursor-pointer text-center bg-dark text-height-2 font-weight-normal px-3 py-2 text-white " onClick={() => handleSort('j')}>J</button>
                            <button class="company_jobs_section_2_button_sub d-inline-block mr-1 mb-2 text-uppercase position-relative z-index-1 overflow-hidden align-middle rounded cursor-pointer text-center bg-dark text-height-2 font-weight-normal px-3 py-2 text-white " onClick={() => handleSort('k')}>K</button>
                            <button class="company_jobs_section_2_button_sub d-inline-block mr-1 mb-2 text-uppercase position-relative z-index-1 overflow-hidden align-middle rounded cursor-pointer text-center bg-dark text-height-2 font-weight-normal px-3 py-2 text-white " onClick={() => handleSort('l')}>L</button>
                            <button class="company_jobs_section_2_button_sub d-inline-block mr-1 mb-2 text-uppercase position-relative z-index-1 overflow-hidden align-middle rounded cursor-pointer text-center bg-dark text-height-2 font-weight-normal px-3 py-2 text-white " onClick={() => handleSort('m')}>M</button>
                            <button class="company_jobs_section_2_button_sub d-inline-block mr-1 mb-2 text-uppercase position-relative z-index-1 overflow-hidden align-middle rounded cursor-pointer text-center bg-dark text-height-2 font-weight-normal px-3 py-2 text-white " onClick={() => handleSort('n')}>N</button>
                            <button class="company_jobs_section_2_button_sub d-inline-block mr-1 mb-2 text-uppercase position-relative z-index-1 overflow-hidden align-middle rounded cursor-pointer text-center bg-dark text-height-2 font-weight-normal px-3 py-2 text-white " onClick={() => handleSort('o')}>O</button>
                            <button class="company_jobs_section_2_button_sub d-inline-block mr-1 mb-2 text-uppercase position-relative z-index-1 overflow-hidden align-middle rounded cursor-pointer text-center bg-dark text-height-2 font-weight-normal px-3 py-2 text-white " onClick={() => handleSort('p')}>P</button>
                            <button class="company_jobs_section_2_button_sub d-inline-block mr-1 mb-2 text-uppercase position-relative z-index-1 overflow-hidden align-middle rounded cursor-pointer text-center bg-dark text-height-2 font-weight-normal px-3 py-2 text-white " onClick={() => handleSort('q')}>Q</button>
                            <button class="company_jobs_section_2_button_sub d-inline-block mr-1 mb-2 text-uppercase position-relative z-index-1 overflow-hidden align-middle rounded cursor-pointer text-center bg-dark text-height-2 font-weight-normal px-3 py-2 text-white " onClick={() => handleSort('r')}>R</button>
                            <button class="company_jobs_section_2_button_sub d-inline-block mr-1 mb-2 text-uppercase position-relative z-index-1 overflow-hidden align-middle rounded cursor-pointer text-center bg-dark text-height-2 font-weight-normal px-3 py-2 text-white " onClick={() => handleSort('s')}>S</button>
                            <button class="company_jobs_section_2_button_sub d-inline-block mr-1 mb-2 text-uppercase position-relative z-index-1 overflow-hidden align-middle rounded cursor-pointer text-center bg-dark text-height-2 font-weight-normal px-3 py-2 text-white " onClick={() => handleSort('t')}>T</button>
                            <button class="company_jobs_section_2_button_sub d-inline-block mr-1 mb-2 text-uppercase position-relative z-index-1 overflow-hidden align-middle rounded cursor-pointer text-center bg-dark text-height-2 font-weight-normal px-3 py-2 text-white " onClick={() => handleSort('u')}>U</button>
                            <button class="company_jobs_section_2_button_sub d-inline-block mr-1 mb-2 text-uppercase position-relative z-index-1 overflow-hidden align-middle rounded cursor-pointer text-center bg-dark text-height-2 font-weight-normal px-3 py-2 text-white " onClick={() => handleSort('v')}>V</button>
                            <button class="company_jobs_section_2_button_sub d-inline-block mr-1 mb-2 text-uppercase position-relative z-index-1 overflow-hidden align-middle rounded cursor-pointer text-center bg-dark text-height-2 font-weight-normal px-3 py-2 text-white " onClick={() => handleSort('w')}>W</button>
                            <button class="company_jobs_section_2_button_sub d-inline-block mr-1 mb-2 text-uppercase position-relative z-index-1 overflow-hidden align-middle rounded cursor-pointer text-center bg-dark text-height-2 font-weight-normal px-3 py-2 text-white " onClick={() => handleSort('x')}>X</button>
                            <button class="company_jobs_section_2_button_sub d-inline-block mr-1 mb-2 text-uppercase position-relative z-index-1 overflow-hidden align-middle rounded cursor-pointer text-center bg-dark text-height-2 font-weight-normal px-3 py-2 text-white " onClick={() => handleSort('y')}>Y</button>
                            <button class="company_jobs_section_2_button_sub d-inline-block mr-1 mb-2 text-uppercase position-relative z-index-1 overflow-hidden align-middle rounded cursor-pointer text-center bg-dark text-height-2 font-weight-normal px-3 py-2 text-white " onClick={() => handleSort('z')}>Z</button>
                            {/* <button class="company_jobs_section_2_button_sub d-inline-block mr-1 mb-2 text-uppercase position-relative z-index-1 overflow-hidden align-middle rounded cursor-pointer text-center bg-dark text-height-2 font-weight-normal px-3 py-2 text-white ">0-99</button> */}


                        </div>:null }
                        <div className="row">
                            {
                             location.pathname === '/skilljobs'?
                             skills.map(res => {
                                return <div className="col-lg-3 col-md-6">
                                    <Link to="#">
                                        <a class="company_jobs_anchor py-1 pr-2 my-1 rounded"><span><img src="images/auto_repair.png" alt=""
                                            class="company_jobs_img_1 mr-2 py-1 px-2 d-flex" /></span><span class="company_jobs_img_1_text align-self-center px-2">{res.Skill}</span></a>
                                    </Link>
                                        
                                </div>
                                
                            }):
                            skills.slice(0,15).map(res => {
                                return <div className="col-lg-3 col-md-6">
                                     <Link to="#">
                                        <a class="company_jobs_anchor py-1 pr-2 my-1 rounded"><span>
                                            {/* <img src="images/auto_repair.png" alt=""
                                            class="company_jobs_img_1 mr-2 py-1 px-2 d-flex" /> */}
                                            </span><span class="company_jobs_img_1_text align-self-center px-2">{res.Skill}</span></a>
                                    </Link>
                                </div>
                            })
                            }
                        </div>
                        <div className='mb-3' id='location'>
                        { location.pathname === '/skilljobs' ? null:<Link to="/skilljobs" className='float-right All-Links'>View All Skills</Link>}
                        </div>
                    </div>

                </div>
            </div>

            {/* <div className="container">
                <div className="jobskill_sec_2_sub">

                    <h6 className="jobskill_sec_2_heading_1">BROWSE JOBS BY NON-SKILL</h6>
                    <hr className="bg-light" />
                    <div className="row">
                        <div className="col-lg-3 col-md-6">
                            <a href="#" className="jobskill_anchor_1"><span className="jobskill_img_1_text">Email
                                Marketing</span></a>
                        </div>
                        <div className="col-lg-3 col-md-6">
                            <a href="#" className="jobskill_anchor_1"><span className="jobskill_img_1_text">Philips
                                Software Job</span></a>
                        </div>
                        <div className="col-lg-3 col-md-6">
                            <a href="#" className="jobskill_anchor_1"><span className="jobskill_img_1_text">Direct
                                Job</span></a>
                        </div>
                        <div className="col-lg-3 col-md-6">
                            <a href="#" className="jobskill_anchor_1"><span className="jobskill_img_1_text">Direct
                                Job</span></a>
                        </div>
                        <div className="col-lg-3 col-md-6">
                            <a href="#" className="jobskill_anchor_1"><span className="jobskill_img_1_text">Email
                                Marketing</span></a>
                        </div>
                        <div className="col-lg-3 col-md-6">
                            <a href="#" className="jobskill_anchor_1"><span className="jobskill_img_1_text">Philips
                                Software Job</span></a>
                        </div>
                        <div className="col-lg-3 col-md-6">
                            <a href="#" className="jobskill_anchor_1"><span className="jobskill_img_1_text">Direct
                                Job</span></a>
                        </div>
                        <div className="col-lg-3 col-md-6">
                            <a href="#" className="jobskill_anchor_1"><span className="jobskill_img_1_text">Direct
                                Job</span></a>
                        </div>
                        <div className="col-lg-3 col-md-6">
                            <a href="#" className="jobskill_anchor_1"><span className="jobskill_img_1_text">Email
                                Marketing</span></a>
                        </div>
                        <div className="col-lg-3 col-md-6">
                            <a href="#" className="jobskill_anchor_1"><span className="jobskill_img_1_text">Philips
                                Software Job</span></a>
                        </div>
                        <div className="col-lg-3 col-md-6">
                            <a href="#" className="jobskill_anchor_1"><span className="jobskill_img_1_text">Direct
                                Job</span></a>
                        </div>
                        <div className="col-lg-3 col-md-6">
                            <a href="#" className="jobskill_anchor_1"><span className="jobskill_img_1_text">Direct
                                Job</span></a>
                        </div>
                        <div className="col-lg-3 col-md-6">
                            <a href="#" className="jobskill_anchor_1"><span className="jobskill_img_1_text">Email
                                Marketing</span></a>
                        </div>
                        <div className="col-lg-3 col-md-6">
                            <a href="#" className="jobskill_anchor_1"><span className="jobskill_img_1_text">Philips
                                Software Job</span></a>
                        </div>
                        <div className="col-lg-3 col-md-6">
                            <a href="#" className="jobskill_anchor_1"><span className="jobskill_img_1_text">Direct
                                Job</span></a>
                        </div>
                        <div className="col-lg-3 col-md-6">
                            <a href="#" className="jobskill_anchor_1"><span className="jobskill_img_1_text">Direct
                                Job</span></a>
                        </div>
                        <div className="col-lg-3 col-md-6">
                            <a href="#" className="jobskill_anchor_1"><span className="jobskill_img_1_text">Email
                                Marketing</span></a>
                        </div>
                        <div className="col-lg-3 col-md-6">
                            <a href="#" className="jobskill_anchor_1"><span className="jobskill_img_1_text">Philips
                                Software Job</span></a>
                        </div>
                        <div className="col-lg-3 col-md-6">
                            <a href="#" className="jobskill_anchor_1"><span className="jobskill_img_1_text">Direct
                                Job</span></a>
                        </div>
                        <div className="col-lg-3 col-md-6">
                            <a href="#" className="jobskill_anchor_1"><span className="jobskill_img_1_text">Direct
                                Job</span></a>
                        </div>
                        <div className="col-lg-3 col-md-6">
                            <a href="#" className="jobskill_anchor_1"><span className="jobskill_img_1_text">Email
                                Marketing</span></a>
                        </div>
                        <div className="col-lg-3 col-md-6">
                            <a href="#" className="jobskill_anchor_1"><span className="jobskill_img_1_text">Philips
                                Software Job</span></a>
                        </div>
                        <div className="col-lg-3 col-md-6">
                            <a href="#" className="jobskill_anchor_1"><span className="jobskill_img_1_text">Direct
                                Job</span></a>
                        </div>
                        <div className="col-lg-3 col-md-6">
                            <a href="#" className="jobskill_anchor_1"><span className="jobskill_img_1_text">Direct
                                Job</span></a>
                        </div>
                        <div className="col-lg-3 col-md-6">
                            <a href="#" className="jobskill_anchor_1"><span className="jobskill_img_1_text">Email
                                Marketing</span></a>
                        </div>
                        <div className="col-lg-3 col-md-6">
                            <a href="#" className="jobskill_anchor_1"><span className="jobskill_img_1_text">Philips
                                Software Job</span></a>
                        </div>
                        <div className="col-lg-3 col-md-6">
                            <a href="#" className="jobskill_anchor_1"><span className="jobskill_img_1_text">Direct
                                Job</span></a>
                        </div>
                        <div className="col-lg-3 col-md-6">
                            <a href="#" className="jobskill_anchor_1"><span className="jobskill_img_1_text">Direct
                                Job</span></a>
                        </div>
                        <div className="col-lg-3 col-md-6">
                            <a href="#" className="jobskill_anchor_1"><span className="jobskill_img_1_text">Email
                                Marketing</span></a>
                        </div>
                        <div className="col-lg-3 col-md-6">
                            <a href="#" className="jobskill_anchor_1"><span className="jobskill_img_1_text">Philips
                                Software Job</span></a>
                        </div>
                        <div className="col-lg-3 col-md-6">
                            <a href="#" className="jobskill_anchor_1"><span className="jobskill_img_1_text">Direct
                                Job</span></a>
                        </div>
                        <div className="col-lg-3 col-md-6">
                            <a href="#" className="jobskill_anchor_1"><span className="jobskill_img_1_text">Direct
                                Job</span></a>
                        </div>


                    </div>
                </div>
            </div> */}
        </div>
    )
}

export default SkillJobs