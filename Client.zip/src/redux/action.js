export const Auth=()=>{
    return{
        type:"USER"
    }
}