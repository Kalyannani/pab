import React from 'react'

export const MembershipPlans = () => {
    return (
        <div>
            

        <section className="features-section-6 section">
        <div className="container text-center">
            <h2>Membership Plans</h2>
            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the
                industry's standard dummy.</p>
            <div className="row section-separator">


                <div className="section-header col-md-8">

                </div>


                <div className="pricing-table pricing-table-js col-xs-12">
                    <div className="row">

                        <div className="col-md-4 each-table col-xs-12">
                            <div className="table-single right text-center">

                                <div className="rounded-lg shadow">
                                    <h4 className="text-uppercase font-weight-bold mb-4">Basic</h4>
                                    <h6 className="font-weight-bold" id="fr">Free</h6>
                                    <p className="prd">
                                        Lorem ipsum dolor sit amet consectetur adipisicing, deleniti quama voluptates
                                        amet.
                                    </p> <a href="#"><button id="bt" type="button"
                                            className="btn pricing_signup">SIGNUP</button></a>

                                </div>

                            </div>
                        </div>
                        <div className="col-md-4 each-table">
                            <div className="table-single open text-center active_pricing">

                                <div className=" rounded-lg shadow">
                                    <h4 className="text-uppercase font-weight-bold mb-4" id="hd2">Professional</h4>
                                    <h6 className="font-weight-bold" id="fr">$29 /Installation</h6>
                                    <p className="prd">
                                        Lorem ipsum dolor sit amet consectetur adipisicing, deleniti quama voluptates
                                        amet.
                                    </p> <a href="#"><button id="bt" type="button"
                                            className="btn  pricing_signup">SIGNUP</button></a>

                                </div>

                            </div> 
                        </div> 
                        <div className="col-md-4 each-table">
                            <div className="table-single left text-center">

                                <div className=" rounded-lg shadow">
                                    <h4 className="text-uppercase font-weight-bold mb-4">Extended</h4>
                                    <h6 className="font-weight-bold" id="fr">$29 /Installation</h6>
                                    <p className="prd">
                                        Lorem ipsum dolor sit amet consectetur adipisicing, deleniti quama voluptates
                                        amet.
                                    </p>
                                    <a href="#"><button id="bt" type="button"
                                            className="btn  pricing_signup">SIGNUP</button></a>

                                </div>

                            </div>
                           
                        </div> 

                    </div> 
                </div> 

            </div>
        </div>
    </section>


        </div>
    )
}
export default MembershipPlans;